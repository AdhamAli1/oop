public class MyInteger {
    private int value ;

    public MyInteger(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public boolean isEven(){
        if (value%2==0)
            return true;
        else return false;
    }
    public boolean isOdd(){
        if (value%2==1)
            return true;
        else return false;
    }

    public boolean isPrime(){
        int c=0;
        for (int i=1;i<value;i++){
            if (value%i==0)
                c++;}
        if (c==2) {
            return true;
        }
        else{ return false;}
    }

    public static boolean isEven(int num){
        if (num%2==0)
            return true;
        else return false;
    }
    public static boolean isOdd(int num){
        if (num%2==1)
            return true;
        else return false;
    }

    public static boolean isPrime(int num){
        int c=0;
        for (int i=1;i<num;i++){
            if (num%i==0)
                c++;}
        if (c==2) {
            return true;
        }
        else{ return false;}
    }

    public static boolean isEven(MyInteger x){
        if (x.value%2==0)
            return true;
        else return false;
    }
    public static boolean isOdd(MyInteger x){
        if (x.value%2==1)
            return true;
        else return false;
    }

    public static boolean isPrime(MyInteger x){
        int c=0;
        for (int i=1;i<x.value;i++){
            if (x.value%i==0)
                c++;}
        if (c==2) {
            return true;
        }
        else{ return false;}
    }

    public boolean equals(int num){
        if (num == value)
            return true;
        else return false;
    }


    public boolean equals(MyInteger X){
        if (X.value == value)
            return true;
        else return false;
    }
    





}
