public class Main {
    public static void main(String[] args) {
        Account x = new Account(1122,20000.00,4.5);
        x.deposite(3000.00);
        x.withdraw(2500.00);
        System.out.println(x.getBalance());
        System.out.println(x.getMonthlyInterest());
        System.out.println(x.getDateCreated());
    }
}