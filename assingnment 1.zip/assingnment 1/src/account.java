import java.time.LocalDate;
public class account {
    private int id;
    private double balance;
    private double annualInterestRate;
    public LocalDate dateCreated;


    public account() {
        this.id = 0;
        this.balance = 0;
        this.annualInterestRate = 0;
    }
    public account(int id, double balance, double annualInterestRate)
    {
        this.id=id;
        this.balance=balance;
        this.annualInterestRate=annualInterestRate;
    }
    public int getId()
    {
        return id;
    }
    public double getBalance()
    {
        return id;
    }
    public double getAnnualInterestRate()
    {
        return annualInterestRate;
    }
    public void setId(int id)
    {
        this.id=id;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    public void setAnnualInterestRate(double interestRate)
    {
        this.annualInterestRate=annualInterestRate;
    }

    public LocalDate getDateCreated()
    {
        return dateCreated;
    }
    public double withdraw(double amountWithdrawn)
    {
        this.balance-=amountWithdrawn;
        return amountWithdrawn;
    }
    public double deposit(double amountDepsited)
    {
        this.balance+=amountDepsited;
        return amountDepsited;
    }
public double getMonthlyInterestRate()
{
    double monthlyInterestRate;
    monthlyInterestRate=(this.annualInterestRate/12)/100;
    return monthlyInterestRate;
}

    public double getMonthlyInterest()
{
    return this.balance*this.annualInterestRate*getMonthlyInterestRate();

}

}
