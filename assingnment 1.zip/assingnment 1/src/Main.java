import java.time.LocalDate;
public class Main {
    public static void main(String[] args) {
account adham= new account(1122,20000, 4.5);
adham.withdraw(2500);
adham.deposit(3000);

System.out.printf(adham.getBalance()+"\n"+adham.getMonthlyInterest()+"\n"+adham.getDateCreated() );


    }
}
/*question 8: 1- Programming is made flexible with encapsulation. It means you do not need to edit and update code every time according to new specifications.

2-It helps you in achieving loose coupling.

3-With encapsulation, it's simple and easy to debug an application.

4-It is also possible to alter and make edits to your codebase without disrupting the regular functioning of your program.

4-It enables the programmer to monitor the data accessibility of a class.
question 9: */